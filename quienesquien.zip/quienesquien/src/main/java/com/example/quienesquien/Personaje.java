package com.example.quienesquien;

public class Personaje {

    private String nombre;
    private boolean tieneBigote;
    private boolean usaGafas;
    private boolean usaSombrero;
    private boolean esHombre;
    private boolean TieneBarba;
    private boolean esCalvo;
    private boolean cejasGrandes;
    private String colorDeOjos;
    private String colorPelo;
    private String colorSombrero;
    private String colorPiel;

    Personaje(String name,boolean hm,boolean wg,boolean wh,boolean m, boolean hb,boolean ib,
              boolean beb,String eyesc,String hairc,String hatc,String skinc){
        this.nombre = name;
        this.tieneBigote = hm;
        this.usaGafas = wg;
        this.usaSombrero = wh;
        this.esHombre = m;
        this.TieneBarba = hb;
        this.esCalvo = ib;
        this.cejasGrandes = beb;
        this.colorDeOjos = eyesc;
        this.colorPelo = hairc;
        this.colorSombrero = hatc;
        this.colorPiel = skinc;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean isTieneBigote() {
        return tieneBigote;
    }

    public boolean isUsaGafas() {
        return usaGafas;
    }

    public boolean isUsaSombrero() {
        return usaSombrero;
    }

    public boolean isEsHombre() {
        return esHombre;
    }

    public boolean isTieneBarba() {
        return TieneBarba;
    }

    public boolean isEsCalvo() {
        return esCalvo;
    }

    public boolean isCejasGrandes() {
        return cejasGrandes;
    }

    public String getColorDeOjos() {
        return colorDeOjos;
    }

    public String getColorPelo() {
        return colorPelo;
    }

    public String getColorSombrero() {
        return colorSombrero;
    }

    public String getColorPiel() {
        return colorPiel;
    }



}
