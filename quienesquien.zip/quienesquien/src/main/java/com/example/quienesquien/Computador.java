package com.example.quienesquien;

public class Computador {
}
