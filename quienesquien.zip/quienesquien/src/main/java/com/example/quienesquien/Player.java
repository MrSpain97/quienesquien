package com.example.quienesquien;

import java.util.ArrayList;

public class Player {
    Personaje[] persons = new Personaje[6];

    private  int playerToBeFound = -1;

    int[] recorrdio = new int[6];

    ArrayList<Integer> preguntas;


    public Player() {
        persons[0] = new Personaje ("Marcos",true,false,false,true,false,false,true,"brown","black","none","white");
        persons[1] = new Personaje ("Dilan",false,true,false,true,false,false,false,"blue","red","none","white");
        persons[2] = new Personaje ("Carlos",false,true,false,true,false,true,false,"blue","brown aside","none","white");
        persons[3] = new Personaje ("Brandon",false,false,true,true,false,false,false,"brown","blonde","blue","white");
        persons[4] = new Personaje ("Sebas",true,false,false,true,false,false,false,"brown","brown","none","black");
        persons[5] = new Personaje ("Pablo",false,false,false,false,false,false,false,"blue","blonde","none","white");

        for (int i=0; i<6; i++) {
            recorrdio[i] =1;
        }
    }
    //constr gia to comp
    public Player(int j) {
        persons[0] = new Personaje ("Marcos",true,false,false,true,false,false,true,"brown","black","none","white");
        persons[1] = new Personaje ("Dilan",false,true,false,true,false,false,false,"blue","red","none","white");
        persons[2] = new Personaje ("Carlos",false,true,false,true,false,true,false,"blue","brown aside","none","white");
        persons[3] = new Personaje ("Brandon",false,false,true,true,false,false,false,"brown","blonde","blue","white");
        persons[4] = new Personaje ("Sebas",true,false,false,true,false,false,false,"brown","brown","none","black");
        persons[5] = new Personaje ("Pablo",false,false,false,false,false,false,false,"blue","blonde","none","white");

        for (int i=0; i<6; i++) {
            recorrdio[i] =1;
        }
        preguntas = new ArrayList<Integer>();
    }

    public int getPlayerToBeFound() {
        return playerToBeFound;
    }
    public void setPlayerToBeFound(int pf) {
        playerToBeFound = pf;
    }
}

